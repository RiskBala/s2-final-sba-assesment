package com.online.event.service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.event.model.Event;
import com.online.event.repository.EventCreationRepository;


@Service
public class EventCreationService {

	@Autowired
	private EventCreationRepository eventCreationRepository;
	Logger logger = LoggerFactory.getLogger(EventCreationService.class);
	

	@Autowired
	private SequenceDaoImpl sequenceDaoImpl;
	public Event save(Event event) throws Exception {
		
		logger.info("inside save method - getEventName s"+event.getEventName());
		event.setId(sequenceDaoImpl.getNextSequenceId("Hosting"));
		return eventCreationRepository.save(event);
	}
}