import React from "react";
import "./NotFound.css";

export default () =>
  <div className="NotFound">
    <h3>Welcome to OutReach</h3>
  </div>;
  