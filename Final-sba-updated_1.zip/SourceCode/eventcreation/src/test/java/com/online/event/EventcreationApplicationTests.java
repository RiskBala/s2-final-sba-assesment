package com.online.event;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventcreationApplicationTests {

	
}
