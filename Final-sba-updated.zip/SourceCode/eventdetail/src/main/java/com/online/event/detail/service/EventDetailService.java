package com.online.event.detail.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.online.event.detail.model.Event;

@Service
public interface EventDetailService {
	public List<Event> getEvents(String eventStatus, String roles);

	public String register(String eventId, String userId);

}