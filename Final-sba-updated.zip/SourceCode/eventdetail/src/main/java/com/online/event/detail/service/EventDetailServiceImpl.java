package com.online.event.detail.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.online.event.detail.controller.EventDetailController;
import com.online.event.detail.model.Event;
import com.online.event.detail.model.Registration;
import com.online.event.detail.repository.EventDetailRepository;
import com.online.event.detail.repository.RegistraionRepository;

public class EventDetailServiceImpl implements EventDetailService {

	@Autowired
	private EventDetailRepository eventDetailRepository;
	
	@Autowired
	private RegistraionRepository registraionRepository;
	
	Logger logger = LoggerFactory.getLogger(EventDetailServiceImpl.class);

	enum Roles {
		VOLUNTEER, ADMIN
	}

	public List<Event> getEvents(String eventStatus, String roles) {
		logger.info("inside EventDetailServiceImpl roles "+roles);
		if(roles.equalsIgnoreCase(Roles.ADMIN.name())) {
			return eventDetailRepository.findAll();
		} else {
			return eventDetailRepository.findByStatus(eventStatus);
		}
	}
	
	public String register(String eventId, String userId) {
		List<Registration> fetchRegistration =registraionRepository.findByEventIdAndAssociateId(eventId, userId);
		logger.info("inside EventDetailServiceImpl userId  "+userId+ " eventId "+eventId );
		if (fetchRegistration != null && fetchRegistration.size()>0 ) {
			return "You have already volunteered for this event";
		} else {
			Registration registration = new Registration();
			registration.setEventId(eventId);
			registration.setAssociateId(userId);
			registration = registraionRepository.save(registration);
			return "Your registration ID is " + registration.getId();
		}
	}
	
}
