package com.online.event.detail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventdetailApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventdetailApplication.class, args);
	}

}
